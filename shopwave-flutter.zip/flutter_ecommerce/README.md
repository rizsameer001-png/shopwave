# ShopWave Flutter App

Full-featured Flutter e-commerce app that integrates with the ShopWave MERN backend.

## Quick Start (FlutLab.io)

1. Upload this folder to FlutLab.io
2. The app works immediately with demo mode (no backend needed)
3. To connect to your backend, edit `lib/services/api_service.dart`:

```dart
const String kBaseUrl = 'https://your-backend.com/api';
```

## Local Setup

```bash
flutter pub get
flutter run
```

## Configure Backend URL

Edit `lib/services/api_service.dart`:

```dart
// Android emulator → localhost
const String kBaseUrl = 'http://10.0.2.2:5000/api';

// iOS simulator → localhost  
const String kBaseUrl = 'http://localhost:5000/api';

// Physical device or production
const String kBaseUrl = 'https://your-deployed-backend.com/api';
```

## Features

- 🏠 **Home** — Banner carousel, category grid, featured & new arrivals
- 🔍 **Search** — Full-text search with sort & filters
- 📦 **Product Detail** — Image gallery, size/color picker, reviews
- 🛒 **Cart** — Swipe-to-delete, quantity controls, order summary
- 💳 **Checkout** — 3-step: Shipping → Payment → Review
- 👤 **Auth** — Login, Register, JWT persistence
- 📋 **Orders** — Order history with status tracking
- ❤️ **Wishlist** — Toggle from any product
- 🗂 **Categories** — Browse by category

## Project Structure

```
lib/
├── main.dart                   # App entry, theme, routes
├── models/
│   ├── product.dart            # Product, ProductImage, ProductColor, Review
│   └── user.dart               # AppUser, Address, CartItem, Order
├── providers/
│   ├── auth_provider.dart      # Login, register, token persistence
│   ├── cart_provider.dart      # Cart state, totals, order payload
│   ├── product_provider.dart   # Product listing, detail, related
│   └── wishlist_provider.dart  # Wishlist toggle, sync
├── services/
│   └── api_service.dart        # All REST API calls (configure URL here)
├── screens/
│   ├── splash_screen.dart
│   ├── home_screen.dart        # Bottom nav, home/explore/wishlist/profile
│   ├── product_detail_screen.dart
│   ├── cart_screen.dart
│   ├── checkout_screen.dart
│   ├── orders_screen.dart
│   ├── search_screen.dart
│   ├── category_screen.dart
│   ├── profile_screen.dart
│   ├── wishlist_screen.dart
│   └── auth/
│       ├── login_screen.dart
│       └── register_screen.dart
└── widgets/
    ├── product_card.dart       # Reusable card with wishlist + add to cart
    └── category_chip.dart
```

## REST API Integration

All API calls go through `lib/services/api_service.dart`.

| Feature | Endpoint |
|---|---|
| Login | `POST /api/auth/login` |
| Register | `POST /api/auth/register` |
| Products | `GET /api/products` |
| Product Detail | `GET /api/products/:id` |
| Create Order | `POST /api/orders` |
| My Orders | `GET /api/orders/my` |
| Toggle Wishlist | `POST /api/auth/wishlist/:id` |

JWT token is stored with `shared_preferences` and auto-loaded on app start.
