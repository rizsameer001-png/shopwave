class Address {
  final String id;
  final String label;
  final String fullName;
  final String street;
  final String city;
  final String state;
  final String zipCode;
  final String country;
  final String? phone;
  final bool isDefault;

  Address({required this.id, this.label = 'Home', required this.fullName, required this.street, required this.city, required this.state, required this.zipCode, this.country = 'US', this.phone, this.isDefault = false});

  String get formatted => '$street, $city, $state $zipCode, $country';

  factory Address.fromJson(Map<String, dynamic> j) => Address(
        id: j['_id'] ?? '',
        label: j['label'] ?? 'Home',
        fullName: j['fullName'] ?? '',
        street: j['street'] ?? '',
        city: j['city'] ?? '',
        state: j['state'] ?? '',
        zipCode: j['zipCode'] ?? '',
        country: j['country'] ?? 'US',
        phone: j['phone'],
        isDefault: j['isDefault'] ?? false,
      );

  Map<String, dynamic> toJson() => {'fullName': fullName, 'street': street, 'city': city, 'state': state, 'zipCode': zipCode, 'country': country, if (phone != null) 'phone': phone};
}

class AppUser {
  final String id;
  final String name;
  final String email;
  final String? avatar;
  final String? phone;
  final List<Address> addresses;
  final bool isAdmin;
  final String? token;

  AppUser({required this.id, required this.name, required this.email, this.avatar, this.phone, this.addresses = const [], this.isAdmin = false, this.token});

  String get avatarUrl => avatar?.isNotEmpty == true ? avatar! : 'https://ui-avatars.com/api/?name=${Uri.encodeComponent(name)}&background=6C63FF&color=fff&size=80';

  factory AppUser.fromJson(Map<String, dynamic> j) => AppUser(
        id: j['_id'] ?? j['id'] ?? '',
        name: j['name'] ?? '',
        email: j['email'] ?? '',
        avatar: j['avatar'],
        phone: j['phone'],
        addresses: (j['addresses'] as List<dynamic>? ?? []).map((a) => Address.fromJson(a as Map<String, dynamic>)).toList(),
        isAdmin: j['isAdmin'] ?? false,
        token: j['token'],
      );

  Map<String, dynamic> toJson() => {'_id': id, 'name': name, 'email': email, 'avatar': avatar, 'phone': phone, 'isAdmin': isAdmin, 'token': token};
}

class CartItem {
  final String productId;
  final String name;
  final String image;
  final double price;
  int quantity;
  final String? size;
  final String? color;

  CartItem({required this.productId, required this.name, required this.image, required this.price, this.quantity = 1, this.size, this.color});

  String get key => '$productId-${size ?? ''}-${color ?? ''}';
  double get subtotal => price * quantity;

  Map<String, dynamic> toJson() => {'product': productId, 'name': name, 'image': image, 'price': price, 'quantity': quantity, if (size != null) 'size': size, if (color != null) 'color': color};
}

class Order {
  final String id;
  final String orderNumber;
  final List<CartItem> items;
  final Address shippingAddress;
  final double itemsPrice;
  final double shippingPrice;
  final double taxPrice;
  final double totalPrice;
  final String status;
  final String paymentMethod;
  final bool isPaid;
  final bool isDelivered;
  final DateTime createdAt;
  final String? trackingNumber;

  Order({required this.id, required this.orderNumber, required this.items, required this.shippingAddress, required this.itemsPrice, required this.shippingPrice, required this.taxPrice, required this.totalPrice, required this.status, required this.paymentMethod, this.isPaid = false, this.isDelivered = false, required this.createdAt, this.trackingNumber});

  factory Order.fromJson(Map<String, dynamic> j) => Order(
        id: j['_id'] ?? '',
        orderNumber: j['orderNumber'] ?? j['_id'] ?? '',
        items: (j['items'] as List<dynamic>? ?? []).map((i) => CartItem(productId: i['product']?.toString() ?? '', name: i['name'] ?? '', image: i['image'] ?? '', price: (i['price'] ?? 0).toDouble(), quantity: i['quantity'] ?? 1, size: i['size'], color: i['color'])).toList(),
        shippingAddress: Address.fromJson(j['shippingAddress'] ?? {}),
        itemsPrice: (j['itemsPrice'] ?? 0).toDouble(),
        shippingPrice: (j['shippingPrice'] ?? 0).toDouble(),
        taxPrice: (j['taxPrice'] ?? 0).toDouble(),
        totalPrice: (j['totalPrice'] ?? 0).toDouble(),
        status: j['status'] ?? 'Pending',
        paymentMethod: j['paymentMethod'] ?? '',
        isPaid: j['isPaid'] ?? false,
        isDelivered: j['isDelivered'] ?? false,
        createdAt: j['createdAt'] != null ? DateTime.parse(j['createdAt']) : DateTime.now(),
        trackingNumber: j['trackingNumber'],
      );
}
