class ProductImage {
  final String url;
  final String alt;
  ProductImage({required this.url, this.alt = ''});
  factory ProductImage.fromJson(Map<String, dynamic> j) =>
      ProductImage(url: j['url'] ?? '', alt: j['alt'] ?? '');
  static String firstUrl(List<ProductImage> images) =>
      images.isNotEmpty ? images[0].url : 'https://via.placeholder.com/400';
}

class ProductColor {
  final String name;
  final String hex;
  ProductColor({required this.name, this.hex = '#ccc'});
  factory ProductColor.fromJson(Map<String, dynamic> j) =>
      ProductColor(name: j['name'] ?? '', hex: j['hex'] ?? '#ccc');
}

class Product {
  final String id;
  final String name;
  final String description;
  final String shortDescription;
  final double price;
  final double? discountPrice;
  final String category;
  final String brand;
  final List<ProductImage> images;
  final int stock;
  final List<String> sizes;
  final List<ProductColor> colors;
  final List<String> tags;
  final double rating;
  final int numReviews;
  final bool isFeatured;
  final bool isNew;
  final String? sku;

  Product({
    required this.id,
    required this.name,
    required this.description,
    this.shortDescription = '',
    required this.price,
    this.discountPrice,
    required this.category,
    required this.brand,
    this.images = const [],
    this.stock = 0,
    this.sizes = const [],
    this.colors = const [],
    this.tags = const [],
    this.rating = 0,
    this.numReviews = 0,
    this.isFeatured = false,
    this.isNew = false,
    this.sku,
  });

  double get effectivePrice => discountPrice != null && discountPrice! < price ? discountPrice! : price;
  bool get hasDiscount => discountPrice != null && discountPrice! < price;
  int get discountPercent => hasDiscount ? ((price - discountPrice!) / price * 100).round() : 0;
  bool get inStock => stock > 0;
  String get firstImageUrl => ProductImage.firstUrl(images);

  factory Product.fromJson(Map<String, dynamic> j) => Product(
        id: j['_id'] ?? j['id'] ?? '',
        name: j['name'] ?? '',
        description: j['description'] ?? '',
        shortDescription: j['shortDescription'] ?? '',
        price: (j['price'] ?? 0).toDouble(),
        discountPrice: j['discountPrice'] != null ? (j['discountPrice']).toDouble() : null,
        category: j['category'] ?? '',
        brand: j['brand'] ?? '',
        images: (j['images'] as List<dynamic>? ?? []).map((i) => ProductImage.fromJson(i is Map ? i as Map<String, dynamic> : {'url': i.toString()})).toList(),
        stock: j['stock'] ?? 0,
        sizes: List<String>.from(j['sizes'] ?? []),
        colors: (j['colors'] as List<dynamic>? ?? []).map((c) => ProductColor.fromJson(c is Map ? c as Map<String, dynamic> : {'name': c.toString()})).toList(),
        tags: List<String>.from(j['tags'] ?? []),
        rating: (j['rating'] ?? 0).toDouble(),
        numReviews: j['numReviews'] ?? 0,
        isFeatured: j['isFeatured'] ?? false,
        isNew: j['isNew'] ?? false,
        sku: j['sku'],
      );
}

class Review {
  final String id;
  final String userName;
  final String? userAvatar;
  final int rating;
  final String comment;
  final DateTime createdAt;

  Review({required this.id, required this.userName, this.userAvatar, required this.rating, required this.comment, required this.createdAt});

  factory Review.fromJson(Map<String, dynamic> j) => Review(
        id: j['_id'] ?? '',
        userName: j['name'] ?? 'User',
        userAvatar: j['avatar'],
        rating: j['rating'] ?? 5,
        comment: j['comment'] ?? '',
        createdAt: j['createdAt'] != null ? DateTime.parse(j['createdAt']) : DateTime.now(),
      );
}
