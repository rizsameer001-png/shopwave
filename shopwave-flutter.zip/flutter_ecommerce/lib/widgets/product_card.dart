import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../models/product.dart';
import '../providers/cart_provider.dart';
import '../providers/wishlist_provider.dart';
import '../main.dart';

class ProductCard extends StatelessWidget {
  final Product product;
  const ProductCard({super.key, required this.product});

  @override
  Widget build(BuildContext context) {
    final wishlist = context.watch<WishlistProvider>();
    final isWishlisted = wishlist.isWishlisted(product.id);

    return GestureDetector(
      onTap: () => Navigator.pushNamed(context, '/product', arguments: product.id),
      child: Container(
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(20),
          boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.07), blurRadius: 12, offset: const Offset(0, 4))],
        ),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          // Image
          Stack(children: [
            ClipRRect(
              borderRadius: const BorderRadius.vertical(top: Radius.circular(20)),
              child: AspectRatio(
                aspectRatio: 1,
                child: Image.network(
                  product.firstImageUrl,
                  fit: BoxFit.cover,
                  errorBuilder: (_, __, ___) => Container(color: const Color(0xFFF5F5F5), child: const Icon(Icons.image_not_supported, size: 48, color: Colors.grey)),
                ),
              ),
            ),
            // Badges
            Positioned(top: 8, left: 8, child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              if (product.hasDiscount) _badge('-${product.discountPercent}%', AppTheme.secondaryColor),
              if (product.isNew) ...[const SizedBox(height: 4), _badge('NEW', AppTheme.accentColor)],
              if (!product.inStock) ...[const SizedBox(height: 4), _badge('SOLD OUT', Colors.grey)],
            ])),
            // Wishlist
            Positioned(top: 6, right: 6, child: GestureDetector(
              onTap: () => wishlist.toggle(product.id),
              child: Container(
                width: 34, height: 34,
                decoration: BoxDecoration(color: Colors.white, shape: BoxShape.circle, boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.12), blurRadius: 6)]),
                child: Icon(isWishlisted ? Icons.favorite : Icons.favorite_border, size: 18, color: isWishlisted ? AppTheme.secondaryColor : Colors.grey),
              ),
            )),
          ]),
          // Info
          Padding(
            padding: const EdgeInsets.all(12),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(product.brand, style: const TextStyle(fontSize: 10, color: Colors.grey, fontWeight: FontWeight.w600, letterSpacing: 0.5)),
              const SizedBox(height: 3),
              Text(product.name, maxLines: 2, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w600, height: 1.3)),
              const SizedBox(height: 6),
              Row(children: [
                const Icon(Icons.star, size: 12, color: Color(0xFFF5A623)),
                const SizedBox(width: 2),
                Text('${product.rating.toStringAsFixed(1)} (${product.numReviews})', style: const TextStyle(fontSize: 10, color: Colors.grey)),
              ]),
              const SizedBox(height: 8),
              Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text('\$${product.effectivePrice.toStringAsFixed(2)}', style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w800, color: AppTheme.primaryColor)),
                  if (product.hasDiscount) Text('\$${product.price.toStringAsFixed(2)}', style: const TextStyle(fontSize: 11, color: Colors.grey, decoration: TextDecoration.lineThrough)),
                ]),
                GestureDetector(
                  onTap: product.inStock ? () {
                    context.read<CartProvider>().addItem(product);
                    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                      content: Text('${product.name.substring(0, product.name.length.clamp(0, 20))}... added to cart'),
                      duration: const Duration(seconds: 1),
                      backgroundColor: AppTheme.primaryColor,
                      behavior: SnackBarBehavior.floating,
                    ));
                  } : null,
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 7),
                    decoration: BoxDecoration(
                      color: product.inStock ? AppTheme.primaryColor : Colors.grey.shade300,
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: Text(product.inStock ? '+ Cart' : '✕', style: TextStyle(color: product.inStock ? Colors.white : Colors.grey, fontSize: 12, fontWeight: FontWeight.w700)),
                  ),
                ),
              ]),
            ]),
          ),
        ]),
      ),
    );
  }

  Widget _badge(String text, Color color) => Container(
    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
    decoration: BoxDecoration(color: color, borderRadius: BorderRadius.circular(8)),
    child: Text(text, style: const TextStyle(color: Colors.white, fontSize: 10, fontWeight: FontWeight.w700)),
  );
}
