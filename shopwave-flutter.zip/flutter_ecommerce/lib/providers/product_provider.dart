import 'package:flutter/material.dart';
import '../models/product.dart';
import '../services/api_service.dart';

class ProductProvider with ChangeNotifier {
  List<Product> _products = [];
  List<Product> _featured = [];
  List<Product> _newArrivals = [];
  Product? _selected;
  List<Product> _related = [];

  bool _loading = false;
  bool _hasMore = true;
  int _page = 1;
  int _totalPages = 1;
  String? _error;

  List<Product> get products => _products;
  List<Product> get featured => _featured;
  List<Product> get newArrivals => _newArrivals;
  Product? get selected => _selected;
  List<Product> get related => _related;
  bool get loading => _loading;
  bool get hasMore => _hasMore;
  String? get error => _error;

  Future<void> fetchFeatured() async {
    try {
      final data = await ApiService.getFeatured();
      final list = data['data'] as List? ?? data as List? ?? [];
      _featured = list.map((j) => Product.fromJson(j as Map<String, dynamic>)).toList();
      notifyListeners();
    } catch (e) { _error = e.toString(); notifyListeners(); }
  }

  Future<void> fetchNewArrivals() async {
    try {
      final data = await ApiService.getNewArrivals();
      final list = data['data'] as List? ?? [];
      _newArrivals = list.map((j) => Product.fromJson(j as Map<String, dynamic>)).toList();
      notifyListeners();
    } catch (_) {}
  }

  Future<void> fetchProducts({
    String? keyword,
    String? category,
    String? sort,
    bool refresh = false,
    double? minPrice,
    double? maxPrice,
  }) async {
    if (refresh) { _page = 1; _products = []; _hasMore = true; }
    if (!_hasMore || _loading) return;
    _loading = true; _error = null; notifyListeners();
    try {
      final data = await ApiService.getProducts(
        keyword: keyword, category: category, sort: sort,
        page: _page, limit: 12, minPrice: minPrice, maxPrice: maxPrice,
      );
      final list = (data['products'] as List? ?? [])
          .map((j) => Product.fromJson(j as Map<String, dynamic>)).toList();
      _totalPages = data['pages'] ?? 1;
      _hasMore = _page < _totalPages;
      _page++;
      _products = refresh ? list : [..._products, ...list];
    } catch (e) { _error = e.toString(); }
    _loading = false; notifyListeners();
  }

  Future<void> fetchProduct(String id) async {
    _loading = true; _error = null; notifyListeners();
    try {
      final data = await ApiService.getProduct(id);
      _selected = Product.fromJson(data);
    } catch (e) { _error = e.toString(); }
    _loading = false; notifyListeners();
  }

  Future<void> fetchRelated(String id) async {
    try {
      final data = await ApiService.getRelated(id);
      final list = data['data'] as List? ?? [];
      _related = list.map((j) => Product.fromJson(j as Map<String, dynamic>)).toList();
      notifyListeners();
    } catch (_) { _related = []; }
  }
}
