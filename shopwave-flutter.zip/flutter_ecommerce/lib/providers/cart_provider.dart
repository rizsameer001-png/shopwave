import 'package:flutter/material.dart';
import '../models/product.dart';
import '../models/user.dart';

class CartProvider with ChangeNotifier {
  final List<CartItem> _items = [];

  List<CartItem> get items => List.unmodifiable(_items);
  int get itemCount => _items.fold(0, (s, i) => s + i.quantity);
  double get subtotal => _items.fold(0, (s, i) => s + i.subtotal);
  double get shipping => subtotal >= 50 ? 0 : 9.99;
  double get tax => subtotal * 0.1;
  double get total => subtotal + shipping + tax;
  bool get isEmpty => _items.isEmpty;

  void addItem(Product product, {String? size, String? color, int qty = 1}) {
    final key = '${product.id}-${size ?? ''}-${color ?? ''}';
    final idx = _items.indexWhere((i) => i.key == key);
    if (idx >= 0) {
      _items[idx].quantity += qty;
    } else {
      _items.add(CartItem(
        productId: product.id,
        name: product.name,
        image: product.firstImageUrl,
        price: product.effectivePrice,
        quantity: qty,
        size: size,
        color: color,
      ));
    }
    notifyListeners();
  }

  void removeItem(String key) {
    _items.removeWhere((i) => i.key == key);
    notifyListeners();
  }

  void updateQuantity(String key, int qty) {
    final idx = _items.indexWhere((i) => i.key == key);
    if (idx < 0) return;
    if (qty <= 0) {
      _items.removeAt(idx);
    } else {
      _items[idx].quantity = qty;
    }
    notifyListeners();
  }

  void clear() {
    _items.clear();
    notifyListeners();
  }

  bool contains(String productId) => _items.any((i) => i.productId == productId);

  Map<String, dynamic> toOrderPayload(Map<String, dynamic> shippingAddress, String paymentMethod) => {
    'items': _items.map((i) => i.toJson()).toList(),
    'shippingAddress': shippingAddress,
    'paymentMethod': paymentMethod,
    'itemsPrice': subtotal,
    'shippingPrice': shipping,
    'taxPrice': tax,
    'totalPrice': total,
  };
}
