import 'package:flutter/material.dart';
import '../services/api_service.dart';

class WishlistProvider with ChangeNotifier {
  final Set<String> _ids = {};
  bool _loading = false;

  Set<String> get ids => _ids;
  bool get loading => _loading;
  bool isWishlisted(String productId) => _ids.contains(productId);

  void loadFromUser(List<dynamic> wishlist) {
    _ids.clear();
    for (final item in wishlist) {
      if (item is String) _ids.add(item);
      if (item is Map) _ids.add(item['_id']?.toString() ?? '');
    }
    notifyListeners();
  }

  Future<bool> toggle(String productId) async {
    final wasIn = _ids.contains(productId);
    if (wasIn) { _ids.remove(productId); } else { _ids.add(productId); }
    notifyListeners();
    try {
      await ApiService.toggleWishlist(productId);
      return !wasIn;
    } catch (_) {
      // rollback
      if (wasIn) { _ids.add(productId); } else { _ids.remove(productId); }
      notifyListeners();
      rethrow;
    }
  }
}
