import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/user.dart';
import '../services/api_service.dart';

class AuthProvider with ChangeNotifier {
  AppUser? _user;
  bool _loading = false;
  String? _error;

  AppUser? get user => _user;
  bool get loading => _loading;
  String? get error => _error;
  bool get isLoggedIn => _user != null;
  bool get isAdmin => _user?.isAdmin ?? false;

  Future<void> tryAutoLogin() async {
    final prefs = await SharedPreferences.getInstance();
    final userJson = prefs.getString('shopwave_user');
    final token = prefs.getString('shopwave_token');
    if (userJson != null && token != null) {
      _user = AppUser.fromJson(jsonDecode(userJson));
      await ApiService.loadToken();
      notifyListeners();
      // Verify token is still valid
      try {
        final fresh = await ApiService.getMe();
        _user = AppUser.fromJson({...fresh, 'token': token});
        await _persistUser(_user!);
        notifyListeners();
      } catch (_) {
        await logout();
      }
    }
  }

  Future<bool> login(String email, String password) async {
    _loading = true; _error = null; notifyListeners();
    try {
      final data = await ApiService.login(email, password);
      _user = AppUser.fromJson(data);
      await _persistUser(_user!);
      _loading = false; notifyListeners();
      return true;
    } on ApiException catch (e) {
      _error = e.message;
    } catch (_) {
      _error = 'Network error. Check your connection.';
    }
    _loading = false; notifyListeners();
    return false;
  }

  Future<bool> register(String name, String email, String password) async {
    _loading = true; _error = null; notifyListeners();
    try {
      final data = await ApiService.register(name, email, password);
      _user = AppUser.fromJson(data);
      await _persistUser(_user!);
      _loading = false; notifyListeners();
      return true;
    } on ApiException catch (e) {
      _error = e.message;
    } catch (_) {
      _error = 'Network error. Check your connection.';
    }
    _loading = false; notifyListeners();
    return false;
  }

  Future<void> logout() async {
    _user = null;
    await ApiService.clearToken();
    notifyListeners();
  }

  void clearError() { _error = null; notifyListeners(); }

  Future<void> _persistUser(AppUser user) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('shopwave_user', jsonEncode(user.toJson()));
  }
}
