import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/product_provider.dart';
import '../providers/cart_provider.dart';
import '../providers/auth_provider.dart';
import '../widgets/product_card.dart';
import '../main.dart';

const _categories = ['All', 'Electronics', 'Fashion', 'Sports', 'Beauty', 'Home', 'Books', 'Toys', 'Grocery'];
const _catIcons   = ['🛍️', '📱', '👗', '⚽', '💄', '🏠', '📚', '🧸', '🍎'];

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});
  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int _tab = 0;
  String _selectedCategory = 'All';
  final _searchCtrl = TextEditingController();

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      final pp = context.read<ProductProvider>();
      pp.fetchFeatured();
      pp.fetchNewArrivals();
      pp.fetchProducts(refresh: true);
    });
  }

  @override
  void dispose() { _searchCtrl.dispose(); super.dispose(); }

  void _selectCategory(String cat) {
    setState(() => _selectedCategory = cat);
    context.read<ProductProvider>().fetchProducts(
      refresh: true,
      category: cat == 'All' ? null : cat,
    );
  }

  @override
  Widget build(BuildContext context) {
    final cartCount = context.watch<CartProvider>().itemCount;
    final auth = context.watch<AuthProvider>();

    return Scaffold(
      backgroundColor: const Color(0xFFF8F9FA),
      body: IndexedStack(index: _tab, children: [
        _HomeTab(selectedCategory: _selectedCategory, onCategoryTap: _selectCategory, searchCtrl: _searchCtrl),
        _ExploreTab(),
        const _WishlistTab(),
        _ProfileTab(),
      ]),
      bottomNavigationBar: NavigationBar(
        selectedIndex: _tab,
        onDestinationSelected: (i) => setState(() => _tab = i),
        backgroundColor: Colors.white,
        elevation: 0,
        shadowColor: Colors.black12,
        destinations: [
          const NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label: 'Home'),
          const NavigationDestination(icon: Icon(Icons.explore_outlined), selectedIcon: Icon(Icons.explore), label: 'Explore'),
          const NavigationDestination(icon: Icon(Icons.favorite_outline), selectedIcon: Icon(Icons.favorite), label: 'Wishlist'),
          NavigationDestination(
            icon: auth.isLoggedIn ? CircleAvatar(radius: 12, backgroundImage: NetworkImage(auth.user!.avatarUrl)) : const Icon(Icons.person_outline),
            selectedIcon: auth.isLoggedIn ? CircleAvatar(radius: 12, backgroundImage: NetworkImage(auth.user!.avatarUrl)) : const Icon(Icons.person),
            label: 'Profile',
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () => Navigator.pushNamed(context, '/cart'),
        backgroundColor: AppTheme.primaryColor,
        child: Stack(children: [
          const Icon(Icons.shopping_cart, color: Colors.white),
          if (cartCount > 0) Positioned(top: 0, right: 0, child: Container(
            width: 14, height: 14,
            decoration: const BoxDecoration(color: AppTheme.secondaryColor, shape: BoxShape.circle),
            child: Center(child: Text('$cartCount', style: const TextStyle(color: Colors.white, fontSize: 8, fontWeight: FontWeight.bold))),
          )),
        ]),
      ),
    );
  }
}

// ─── Home Tab ──────────────────────────────────────────────────────────────
class _HomeTab extends StatelessWidget {
  final String selectedCategory;
  final void Function(String) onCategoryTap;
  final TextEditingController searchCtrl;
  const _HomeTab({required this.selectedCategory, required this.onCategoryTap, required this.searchCtrl});

  @override
  Widget build(BuildContext context) {
    final pp = context.watch<ProductProvider>();
    final auth = context.watch<AuthProvider>();

    return CustomScrollView(slivers: [
      // AppBar
      SliverAppBar(
        floating: true, pinned: false, expandedHeight: 120,
        backgroundColor: Colors.white, elevation: 0,
        flexibleSpace: FlexibleSpaceBar(
          background: Container(
            color: Colors.white,
            padding: const EdgeInsets.fromLTRB(20, 50, 20, 0),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Row(children: [
                Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text('Hi, ${auth.isLoggedIn ? auth.user!.name.split(' ')[0] : 'Shopper'}! 👋', style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w800)),
                  const Text("What are you shopping for?", style: TextStyle(color: Colors.grey, fontSize: 13)),
                ])),
                GestureDetector(
                  onTap: () => Navigator.pushNamed(context, '/cart'),
                  child: Container(
                    padding: const EdgeInsets.all(10),
                    decoration: BoxDecoration(color: AppTheme.primaryColor.withOpacity(0.1), borderRadius: BorderRadius.circular(12)),
                    child: const Icon(Icons.shopping_cart_outlined, color: AppTheme.primaryColor),
                  ),
                ),
              ]),
            ]),
          ),
        ),
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(56),
          child: Padding(
            padding: const EdgeInsets.fromLTRB(16, 0, 16, 8),
            child: GestureDetector(
              onTap: () => Navigator.pushNamed(context, '/search'),
              child: Container(
                height: 48,
                decoration: BoxDecoration(color: const Color(0xFFF5F5F5), borderRadius: BorderRadius.circular(14)),
                child: const Row(children: [
                  SizedBox(width: 16),
                  Icon(Icons.search, color: Colors.grey),
                  SizedBox(width: 10),
                  Text('Search products, brands...', style: TextStyle(color: Colors.grey, fontSize: 14)),
                ]),
              ),
            ),
          ),
        ),
      ),

      SliverToBoxAdapter(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        // Banner
        _HeroBanner(),
        const SizedBox(height: 24),

        // Categories
        const Padding(padding: EdgeInsets.fromLTRB(20, 0, 20, 12), child: Text('Shop by Category', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800))),
        SizedBox(
          height: 90,
          child: ListView.separated(
            scrollDirection: Axis.horizontal,
            padding: const EdgeInsets.symmetric(horizontal: 16),
            itemCount: _categories.length,
            separatorBuilder: (_, __) => const SizedBox(width: 10),
            itemBuilder: (ctx, i) {
              final selected = _categories[i] == selectedCategory;
              return GestureDetector(
                onTap: () => onCategoryTap(_categories[i]),
                child: AnimatedContainer(
                  duration: const Duration(milliseconds: 200),
                  width: 70,
                  decoration: BoxDecoration(
                    color: selected ? AppTheme.primaryColor : Colors.white,
                    borderRadius: BorderRadius.circular(16),
                    boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.06), blurRadius: 8)],
                  ),
                  child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                    Text(_catIcons[i], style: const TextStyle(fontSize: 26)),
                    const SizedBox(height: 4),
                    Text(_categories[i], textAlign: TextAlign.center, style: TextStyle(fontSize: 10, fontWeight: FontWeight.w600, color: selected ? Colors.white : Colors.grey.shade700)),
                  ]),
                ),
              );
            },
          ),
        ),
        const SizedBox(height: 28),

        // Featured
        if (pp.featured.isNotEmpty) ...[
          const Padding(padding: EdgeInsets.fromLTRB(20, 0, 20, 12), child: Text('⭐ Featured', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800))),
          SizedBox(
            height: 280,
            child: ListView.separated(
              scrollDirection: Axis.horizontal,
              padding: const EdgeInsets.symmetric(horizontal: 16),
              itemCount: pp.featured.length,
              separatorBuilder: (_, __) => const SizedBox(width: 14),
              itemBuilder: (ctx, i) => SizedBox(width: 190, child: ProductCard(product: pp.featured[i])),
            ),
          ),
          const SizedBox(height: 28),
        ],

        // New Arrivals
        if (pp.newArrivals.isNotEmpty) ...[
          const Padding(padding: EdgeInsets.fromLTRB(20, 0, 20, 12), child: Text('🆕 New Arrivals', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800))),
          SizedBox(
            height: 280,
            child: ListView.separated(
              scrollDirection: Axis.horizontal,
              padding: const EdgeInsets.symmetric(horizontal: 16),
              itemCount: pp.newArrivals.length,
              separatorBuilder: (_, __) => const SizedBox(width: 14),
              itemBuilder: (ctx, i) => SizedBox(width: 190, child: ProductCard(product: pp.newArrivals[i])),
            ),
          ),
          const SizedBox(height: 28),
        ],

        // All Products
        Padding(
          padding: const EdgeInsets.fromLTRB(20, 0, 20, 12),
          child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
            Text(selectedCategory == 'All' ? 'All Products' : selectedCategory, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
            TextButton(onPressed: () => Navigator.pushNamed(context, '/search'), child: const Text('See All')),
          ]),
        ),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16),
          child: GridView.builder(
            physics: const NeverScrollableScrollPhysics(),
            shrinkWrap: true,
            gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 2, childAspectRatio: 0.65, crossAxisSpacing: 14, mainAxisSpacing: 14),
            itemCount: pp.loading && pp.products.isEmpty ? 4 : pp.products.length,
            itemBuilder: (ctx, i) {
              if (pp.loading && pp.products.isEmpty) return _SkeletonCard();
              return ProductCard(product: pp.products[i]);
            },
          ),
        ),
        const SizedBox(height: 90),
      ])),
    ]);
  }
}

class _HeroBanner extends StatefulWidget {
  @override
  State<_HeroBanner> createState() => _HeroBannerState();
}
class _HeroBannerState extends State<_HeroBanner> {
  int _idx = 0;
  final _banners = [
    {'title': 'Summer Sale', 'sub': 'Up to 50% OFF', 'emoji': '☀️', 'colors': [const Color(0xFF667EEA), const Color(0xFF764BA2)]},
    {'title': 'New Arrivals', 'sub': 'Shop the latest', 'emoji': '🌟', 'colors': [const Color(0xFFFF6B9D), const Color(0xFFFF8E53)]},
    {'title': 'Free Shipping', 'sub': 'Orders over \$50', 'emoji': '🚚', 'colors': [const Color(0xFF43E97B), const Color(0xFF38F9D7)]},
  ];

  @override
  void initState() {
    super.initState();
    Future.doWhile(() async {
      await Future.delayed(const Duration(seconds: 3));
      if (!mounted) return false;
      setState(() => _idx = (_idx + 1) % _banners.length);
      return true;
    });
  }

  @override
  Widget build(BuildContext context) {
    final b = _banners[_idx];
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: AnimatedSwitcher(
        duration: const Duration(milliseconds: 500),
        child: Container(
          key: ValueKey(_idx),
          height: 140,
          decoration: BoxDecoration(
            gradient: LinearGradient(colors: b['colors'] as List<Color>),
            borderRadius: BorderRadius.circular(24),
          ),
          padding: const EdgeInsets.all(24),
          child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
            Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisAlignment: MainAxisAlignment.center, children: [
              Text(b['title'] as String, style: const TextStyle(color: Colors.white, fontSize: 22, fontWeight: FontWeight.w800)),
              const SizedBox(height: 4),
              Text(b['sub'] as String, style: TextStyle(color: Colors.white.withOpacity(0.85), fontSize: 14)),
              const SizedBox(height: 12),
              ElevatedButton(
                onPressed: () => Navigator.pushNamed(context, '/search'),
                style: ElevatedButton.styleFrom(backgroundColor: Colors.white, foregroundColor: AppTheme.primaryColor, padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8), minimumSize: Size.zero, tapTargetSize: MaterialTapTargetSize.shrinkWrap),
                child: const Text('Shop Now', style: TextStyle(fontSize: 12, fontWeight: FontWeight.w700)),
              ),
            ]),
            Text(b['emoji'] as String, style: const TextStyle(fontSize: 60)),
          ]),
        ),
      ),
    );
  }
}

class _SkeletonCard extends StatelessWidget {
  @override
  Widget build(BuildContext context) => Container(
    decoration: BoxDecoration(color: Colors.grey.shade100, borderRadius: BorderRadius.circular(20)),
  );
}

// ─── Explore Tab ───────────────────────────────────────────────────────────
class _ExploreTab extends StatelessWidget {
  final _cats = const [
    {'name': 'Electronics', 'icon': '📱', 'color': 0xFF667EEA},
    {'name': 'Fashion',     'icon': '👗', 'color': 0xFFFF6B9D},
    {'name': 'Sports',      'icon': '⚽', 'color': 0xFF43E97B},
    {'name': 'Beauty',      'icon': '💄', 'color': 0xFFFA709A},
    {'name': 'Home',        'icon': '🏠', 'color': 0xFF4FACFE},
    {'name': 'Books',       'icon': '📚', 'color': 0xFFF093FB},
    {'name': 'Toys',        'icon': '🧸', 'color': 0xFFFDA085},
    {'name': 'Grocery',     'icon': '🍎', 'color': 0xFF5EE7DF},
  ];

  @override
  Widget build(BuildContext context) {
    return CustomScrollView(slivers: [
      const SliverAppBar(title: Text('Explore'), pinned: true),
      SliverPadding(
        padding: const EdgeInsets.all(16),
        sliver: SliverGrid(
          delegate: SliverChildBuilderDelegate(
            (ctx, i) => GestureDetector(
              onTap: () => Navigator.pushNamed(ctx, '/category', arguments: _cats[i]['name']),
              child: Container(
                decoration: BoxDecoration(
                  color: Color(_cats[i]['color'] as int).withOpacity(0.15),
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(color: Color(_cats[i]['color'] as int).withOpacity(0.3)),
                ),
                child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                  Text(_cats[i]['icon'] as String, style: const TextStyle(fontSize: 44)),
                  const SizedBox(height: 8),
                  Text(_cats[i]['name'] as String, style: TextStyle(fontWeight: FontWeight.w700, color: Color(_cats[i]['color'] as int), fontSize: 14)),
                ]),
              ),
            ),
            childCount: _cats.length,
          ),
          gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 2, crossAxisSpacing: 14, mainAxisSpacing: 14, childAspectRatio: 1.1),
        ),
      ),
    ]);
  }
}

// ─── Wishlist Tab ──────────────────────────────────────────────────────────
class _WishlistTab extends StatelessWidget {
  const _WishlistTab();
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('My Wishlist')),
    body: const Center(child: Column(mainAxisSize: MainAxisSize.min, children: [
      Text('💝', style: TextStyle(fontSize: 64)),
      SizedBox(height: 16),
      Text('Your wishlist', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w700)),
      SizedBox(height: 8),
      Text('Tap ♡ on any product to save it here', style: TextStyle(color: Colors.grey)),
    ])),
  );
}

// ─── Profile Tab ───────────────────────────────────────────────────────────
class _ProfileTab extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final auth = context.watch<AuthProvider>();
    return Scaffold(
      appBar: AppBar(title: const Text('My Account')),
      body: ListView(padding: const EdgeInsets.all(20), children: [
        if (auth.isLoggedIn) ...[
          Row(children: [
            CircleAvatar(radius: 36, backgroundImage: NetworkImage(auth.user!.avatarUrl)),
            const SizedBox(width: 16),
            Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(auth.user!.name, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
              Text(auth.user!.email, style: const TextStyle(color: Colors.grey, fontSize: 13)),
              if (auth.isAdmin) Container(margin: const EdgeInsets.only(top: 4), padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 3), decoration: BoxDecoration(color: AppTheme.primaryColor.withOpacity(0.1), borderRadius: BorderRadius.circular(12)), child: const Text('Admin', style: TextStyle(color: AppTheme.primaryColor, fontSize: 12, fontWeight: FontWeight.w700))),
            ]),
          ]),
          const SizedBox(height: 28),
        ] else ...[
          Container(
            padding: const EdgeInsets.all(20), margin: const EdgeInsets.only(bottom: 28),
            decoration: BoxDecoration(gradient: const LinearGradient(colors: [AppTheme.primaryColor, Color(0xFF9C27B0)]), borderRadius: BorderRadius.circular(20)),
            child: Column(children: [
              const Text('Welcome to ShopWave! 🛍️', style: TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.w800)),
              const SizedBox(height: 8),
              const Text('Sign in to access orders, wishlist & more', style: TextStyle(color: Colors.white70, fontSize: 13), textAlign: TextAlign.center),
              const SizedBox(height: 16),
              Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                ElevatedButton(onPressed: () => Navigator.pushNamed(context, '/login'), style: ElevatedButton.styleFrom(backgroundColor: Colors.white, foregroundColor: AppTheme.primaryColor), child: const Text('Sign In')),
                const SizedBox(width: 12),
                OutlinedButton(onPressed: () => Navigator.pushNamed(context, '/register'), style: OutlinedButton.styleFrom(side: const BorderSide(color: Colors.white), foregroundColor: Colors.white), child: const Text('Register')),
              ]),
            ]),
          ),
        ],
        _tile(Icons.shopping_bag_outlined, 'My Orders', () => Navigator.pushNamed(context, '/orders')),
        _tile(Icons.favorite_outline, 'Wishlist', () => Navigator.pushNamed(context, '/wishlist')),
        _tile(Icons.person_outline, 'Profile Settings', () => Navigator.pushNamed(context, '/profile')),
        _tile(Icons.location_on_outlined, 'Addresses', () {}),
        _tile(Icons.help_outline, 'Help & Support', () {}),
        if (auth.isLoggedIn) ...[
          const Divider(height: 32),
          _tile(Icons.logout, 'Sign Out', () => auth.logout(), color: Colors.red),
        ],
      ]),
    );
  }

  Widget _tile(IconData icon, String label, VoidCallback onTap, {Color? color}) {
    return ListTile(
      leading: Icon(icon, color: color ?? AppTheme.primaryColor),
      title: Text(label, style: TextStyle(fontWeight: FontWeight.w600, color: color)),
      trailing: const Icon(Icons.chevron_right, color: Colors.grey),
      onTap: onTap,
      contentPadding: const EdgeInsets.symmetric(horizontal: 4, vertical: 2),
    );
  }
}
