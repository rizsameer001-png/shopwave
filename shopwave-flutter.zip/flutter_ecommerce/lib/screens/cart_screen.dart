import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/cart_provider.dart';
import '../providers/auth_provider.dart';
import '../main.dart';

class CartScreen extends StatelessWidget {
  const CartScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final cart = context.watch<CartProvider>();

    return Scaffold(
      appBar: AppBar(title: Text('Cart (${cart.itemCount})')),
      body: cart.isEmpty
          ? Center(child: Column(mainAxisSize: MainAxisSize.min, children: [
              const Text('🛒', style: TextStyle(fontSize: 72)),
              const SizedBox(height: 16),
              const Text('Your cart is empty', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w700)),
              const SizedBox(height: 8),
              const Text('Add items to get started', style: TextStyle(color: Colors.grey)),
              const SizedBox(height: 28),
              ElevatedButton(onPressed: () => Navigator.pushNamed(context, '/search'), child: const Text('Start Shopping')),
            ]))
          : Column(children: [
              Expanded(child: ListView.builder(
                padding: const EdgeInsets.all(16),
                itemCount: cart.items.length,
                itemBuilder: (ctx, i) {
                  final item = cart.items[i];
                  return Dismissible(
                    key: Key(item.key),
                    direction: DismissDirection.endToStart,
                    background: Container(margin: const EdgeInsets.only(bottom: 12), decoration: BoxDecoration(color: Colors.red.shade50, borderRadius: BorderRadius.circular(16)), alignment: Alignment.centerRight, padding: const EdgeInsets.only(right: 24), child: const Icon(Icons.delete_outline, color: Colors.red)),
                    onDismissed: (_) => cart.removeItem(item.key),
                    child: Container(
                      margin: const EdgeInsets.only(bottom: 12),
                      padding: const EdgeInsets.all(14),
                      decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(16), boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.05), blurRadius: 8)]),
                      child: Row(children: [
                        ClipRRect(borderRadius: BorderRadius.circular(12), child: Image.network(item.image, width: 80, height: 80, fit: BoxFit.cover, errorBuilder: (_, __, ___) => Container(width: 80, height: 80, color: Colors.grey.shade100))),
                        const SizedBox(width: 14),
                        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                          Text(item.name, maxLines: 2, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 14)),
                          if (item.size != null || item.color != null) Text('${item.size ?? ''}${item.size != null && item.color != null ? ' · ' : ''}${item.color ?? ''}', style: const TextStyle(fontSize: 12, color: Colors.grey)),
                          const SizedBox(height: 8),
                          Text('\$${(item.price * item.quantity).toStringAsFixed(2)}', style: const TextStyle(fontWeight: FontWeight.w800, color: AppTheme.primaryColor, fontSize: 16)),
                        ])),
                        Column(children: [
                          IconButton(icon: const Icon(Icons.delete_outline, color: Colors.grey, size: 20), onPressed: () => cart.removeItem(item.key)),
                          Container(decoration: BoxDecoration(border: Border.all(color: Colors.grey.shade200), borderRadius: BorderRadius.circular(10)), child: Row(mainAxisSize: MainAxisSize.min, children: [
                            IconButton(icon: const Icon(Icons.remove, size: 14), onPressed: () => cart.updateQuantity(item.key, item.quantity - 1), padding: const EdgeInsets.all(4), constraints: const BoxConstraints()),
                            Padding(padding: const EdgeInsets.symmetric(horizontal: 8), child: Text('${item.quantity}', style: const TextStyle(fontWeight: FontWeight.w800))),
                            IconButton(icon: const Icon(Icons.add, size: 14), onPressed: () => cart.updateQuantity(item.key, item.quantity + 1), padding: const EdgeInsets.all(4), constraints: const BoxConstraints()),
                          ])),
                        ]),
                      ]),
                    ),
                  );
                },
              )),

              // Summary
              Container(
                padding: const EdgeInsets.all(20),
                decoration: BoxDecoration(color: Colors.white, boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.06), blurRadius: 12, offset: const Offset(0, -4))]),
                child: SafeArea(child: Column(children: [
                  _row('Subtotal', '\$${cart.subtotal.toStringAsFixed(2)}'),
                  const SizedBox(height: 6),
                  _row('Shipping', cart.shipping == 0 ? 'FREE' : '\$${cart.shipping.toStringAsFixed(2)}', valueColor: cart.shipping == 0 ? Colors.green : null),
                  const SizedBox(height: 6),
                  _row('Tax (10%)', '\$${cart.tax.toStringAsFixed(2)}'),
                  const Padding(padding: EdgeInsets.symmetric(vertical: 10), child: Divider()),
                  _row('Total', '\$${cart.total.toStringAsFixed(2)}', bold: true),
                  if (cart.shipping > 0) Padding(padding: const EdgeInsets.only(top: 6), child: Text('Add \$${(50 - cart.subtotal).toStringAsFixed(2)} more for free shipping!', style: const TextStyle(color: Colors.orange, fontSize: 12))),
                  const SizedBox(height: 14),
                  SizedBox(width: double.infinity, child: ElevatedButton(
                    onPressed: () {
                      final auth = context.read<AuthProvider>();
                      if (!auth.isLoggedIn) { Navigator.pushNamed(context, '/login'); return; }
                      Navigator.pushNamed(context, '/checkout');
                    },
                    style: ElevatedButton.styleFrom(padding: const EdgeInsets.symmetric(vertical: 16)),
                    child: const Text('Proceed to Checkout →', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w700)),
                  )),
                ])),
              ),
            ]),
    );
  }

  Widget _row(String label, String value, {bool bold = false, Color? valueColor}) => Row(
    mainAxisAlignment: MainAxisAlignment.spaceBetween,
    children: [
      Text(label, style: TextStyle(color: bold ? Colors.black87 : Colors.grey, fontWeight: bold ? FontWeight.w800 : FontWeight.w400, fontSize: bold ? 16 : 14)),
      Text(value, style: TextStyle(color: valueColor ?? (bold ? AppTheme.primaryColor : Colors.black87), fontWeight: bold ? FontWeight.w800 : FontWeight.w600, fontSize: bold ? 18 : 14)),
    ],
  );
}
