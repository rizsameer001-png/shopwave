import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/cart_provider.dart';
import '../services/api_service.dart';
import '../main.dart';

class CheckoutScreen extends StatefulWidget {
  const CheckoutScreen({super.key});
  @override
  State<CheckoutScreen> createState() => _CheckoutScreenState();
}

class _CheckoutScreenState extends State<CheckoutScreen> {
  int _step = 0;
  bool _placing = false;
  String _paymentMethod = 'Credit Card';
  final _formKey = GlobalKey<FormState>();
  final _nameCtrl    = TextEditingController();
  final _phoneCtrl   = TextEditingController();
  final _streetCtrl  = TextEditingController();
  final _cityCtrl    = TextEditingController();
  final _stateCtrl   = TextEditingController();
  final _zipCtrl     = TextEditingController();

  @override
  void dispose() { _nameCtrl.dispose(); _phoneCtrl.dispose(); _streetCtrl.dispose(); _cityCtrl.dispose(); _stateCtrl.dispose(); _zipCtrl.dispose(); super.dispose(); }

  Future<void> _placeOrder() async {
    setState(() => _placing = true);
    final cart = context.read<CartProvider>();
    try {
      final payload = cart.toOrderPayload({'fullName': _nameCtrl.text, 'phone': _phoneCtrl.text, 'street': _streetCtrl.text, 'city': _cityCtrl.text, 'state': _stateCtrl.text, 'zipCode': _zipCtrl.text, 'country': 'US'}, _paymentMethod);
      final res = await ApiService.createOrder(payload);
      cart.clear();
      if (mounted) {
        showDialog(context: context, barrierDismissible: false, builder: (_) => AlertDialog(
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
          content: Column(mainAxisSize: MainAxisSize.min, children: [
            const Text('🎉', style: TextStyle(fontSize: 64)),
            const SizedBox(height: 12),
            const Text('Order Placed!', style: TextStyle(fontSize: 24, fontWeight: FontWeight.w800)),
            const SizedBox(height: 8),
            Text('Order #${res['orderNumber'] ?? 'confirmed'}', style: const TextStyle(color: AppTheme.primaryColor, fontWeight: FontWeight.w700)),
            const SizedBox(height: 6),
            const Text("We'll send you shipping updates soon.", textAlign: TextAlign.center, style: TextStyle(color: Colors.grey, fontSize: 13)),
            const SizedBox(height: 20),
            ElevatedButton(onPressed: () { Navigator.pop(context); Navigator.pushReplacementNamed(context, '/orders'); }, child: const Text('View Orders')),
          ]),
        ));
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Failed: ${e.toString()}'), backgroundColor: Colors.red));
    } finally {
      if (mounted) setState(() => _placing = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final cart = context.watch<CartProvider>();
    return Scaffold(
      appBar: AppBar(title: const Text('Checkout'), bottom: PreferredSize(preferredSize: const Size.fromHeight(4), child: LinearProgressIndicator(value: (_step + 1) / 3, backgroundColor: Colors.grey.shade100, color: AppTheme.primaryColor))),
      body: Column(children: [
        // Step indicator
        Padding(padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 14), child: Row(children: List.generate(3, (i) {
          final labels = ['Shipping', 'Payment', 'Review'];
          return Expanded(child: Row(children: [
            Column(children: [
              AnimatedContainer(duration: const Duration(milliseconds: 200), width: 30, height: 30, decoration: BoxDecoration(shape: BoxShape.circle, color: i <= _step ? AppTheme.primaryColor : Colors.grey.shade200), child: Center(child: i < _step ? const Icon(Icons.check, color: Colors.white, size: 16) : Text('${i+1}', style: TextStyle(color: i <= _step ? Colors.white : Colors.grey, fontWeight: FontWeight.w700, fontSize: 12)))),
              Text(labels[i], style: TextStyle(fontSize: 10, color: i == _step ? AppTheme.primaryColor : Colors.grey, fontWeight: i == _step ? FontWeight.w700 : FontWeight.w400)),
            ]),
            if (i < 2) Expanded(child: Container(height: 2, color: i < _step ? AppTheme.primaryColor : Colors.grey.shade200, margin: const EdgeInsets.only(bottom: 14))),
          ]));
        }))),

        Expanded(child: SingleChildScrollView(padding: const EdgeInsets.all(20), child: Column(children: [
          if (_step == 0) _buildShipping(),
          if (_step == 1) _buildPayment(),
          if (_step == 2) _buildReview(cart),
        ]))),

        // Buttons
        Container(padding: const EdgeInsets.all(20), color: Colors.white, child: SafeArea(child: Row(children: [
          if (_step > 0) Expanded(child: OutlinedButton(onPressed: () => setState(() => _step--), style: OutlinedButton.styleFrom(padding: const EdgeInsets.symmetric(vertical: 16)), child: const Text('← Back'))),
          if (_step > 0) const SizedBox(width: 12),
          Expanded(child: ElevatedButton(
            onPressed: _placing ? null : () {
              if (_step == 0 && (_formKey.currentState?.validate() != true)) return;
              if (_step < 2) { setState(() => _step++); }
              else { _placeOrder(); }
            },
            style: ElevatedButton.styleFrom(padding: const EdgeInsets.symmetric(vertical: 16)),
            child: _placing ? const SizedBox(height: 20, width: 20, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white)) : Text(_step < 2 ? 'Continue →' : '🎉 Place Order', style: const TextStyle(fontWeight: FontWeight.w700)),
          )),
        ]))),
      ]),
    );
  }

  Widget _buildShipping() => Form(key: _formKey, child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
    const Text('Shipping Address', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
    const SizedBox(height: 16),
    _field(_nameCtrl, 'Full Name', Icons.person_outline, required: true),
    _field(_phoneCtrl, 'Phone Number', Icons.phone_outlined),
    _field(_streetCtrl, 'Street Address', Icons.location_on_outlined, required: true),
    Row(children: [Expanded(child: _field(_cityCtrl, 'City', Icons.location_city_outlined, required: true)), const SizedBox(width: 12), Expanded(child: _field(_stateCtrl, 'State', Icons.map_outlined, required: true))]),
    _field(_zipCtrl, 'ZIP Code', Icons.markunread_mailbox_outlined, required: true),
  ]));

  Widget _field(TextEditingController ctrl, String label, IconData icon, {bool required = false}) => Padding(
    padding: const EdgeInsets.only(bottom: 14),
    child: TextFormField(controller: ctrl, decoration: InputDecoration(labelText: label, prefixIcon: Icon(icon, size: 20)),
      validator: required ? (v) => (v == null || v.isEmpty) ? '$label is required' : null : null),
  );

  Widget _buildPayment() {
    const methods = ['Credit Card', 'PayPal', 'Apple Pay', 'Cash on Delivery'];
    const icons   = ['💳', '🅿️', '🍎', '💵'];
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      const Text('Payment Method', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
      const SizedBox(height: 16),
      ...List.generate(methods.length, (i) => GestureDetector(
        onTap: () => setState(() => _paymentMethod = methods[i]),
        child: AnimatedContainer(duration: const Duration(milliseconds: 200),
          margin: const EdgeInsets.only(bottom: 12),
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: _paymentMethod == methods[i] ? AppTheme.primaryColor.withOpacity(0.05) : Colors.white,
            border: Border.all(color: _paymentMethod == methods[i] ? AppTheme.primaryColor : Colors.grey.shade200, width: _paymentMethod == methods[i] ? 2 : 1),
            borderRadius: BorderRadius.circular(16),
          ),
          child: Row(children: [
            Text(icons[i], style: const TextStyle(fontSize: 24)),
            const SizedBox(width: 14),
            Text(methods[i], style: TextStyle(fontWeight: FontWeight.w600, color: _paymentMethod == methods[i] ? AppTheme.primaryColor : Colors.black87)),
            const Spacer(),
            if (_paymentMethod == methods[i]) const Icon(Icons.check_circle, color: AppTheme.primaryColor),
          ]),
        ),
      )),
    ]);
  }

  Widget _buildReview(CartProvider cart) => Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
    const Text('Review Order', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
    const SizedBox(height: 16),
    _infoCard('📍 Shipping To', '${_nameCtrl.text}\n${_streetCtrl.text}\n${_cityCtrl.text}, ${_stateCtrl.text} ${_zipCtrl.text}'),
    _infoCard('💳 Payment', _paymentMethod),
    const SizedBox(height: 4),
    ...cart.items.map((item) => Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(14), border: Border.all(color: Colors.grey.shade100)),
      child: Row(children: [
        ClipRRect(borderRadius: BorderRadius.circular(8), child: Image.network(item.image, width: 50, height: 50, fit: BoxFit.cover, errorBuilder: (_, __, ___) => Container(width: 50, height: 50, color: Colors.grey.shade100))),
        const SizedBox(width: 12),
        Expanded(child: Text(item.name, maxLines: 2, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 13))),
        Text('×${item.quantity}', style: const TextStyle(color: Colors.grey)),
        const SizedBox(width: 8),
        Text('\$${item.subtotal.toStringAsFixed(2)}', style: const TextStyle(fontWeight: FontWeight.w800)),
      ]),
    )),
    const Divider(),
    _row('Subtotal', '\$${cart.subtotal.toStringAsFixed(2)}'),
    _row('Shipping', cart.shipping == 0 ? 'FREE' : '\$${cart.shipping.toStringAsFixed(2)}'),
    _row('Tax', '\$${cart.tax.toStringAsFixed(2)}'),
    const Divider(),
    _row('Total', '\$${cart.total.toStringAsFixed(2)}', bold: true),
  ]);

  Widget _infoCard(String title, String body) => Container(
    width: double.infinity, margin: const EdgeInsets.only(bottom: 12), padding: const EdgeInsets.all(14),
    decoration: BoxDecoration(color: Colors.grey.shade50, borderRadius: BorderRadius.circular(14)),
    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(title, style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 13, color: Colors.grey)), const SizedBox(height: 6), Text(body, style: const TextStyle(fontSize: 14))]),
  );

  Widget _row(String label, String value, {bool bold = false}) => Padding(
    padding: const EdgeInsets.symmetric(vertical: 4),
    child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
      Text(label, style: TextStyle(color: bold ? Colors.black87 : Colors.grey, fontWeight: bold ? FontWeight.w800 : FontWeight.w400, fontSize: bold ? 16 : 14)),
      Text(value, style: TextStyle(color: bold ? AppTheme.primaryColor : Colors.black87, fontWeight: bold ? FontWeight.w800 : FontWeight.w600, fontSize: bold ? 18 : 14)),
    ]),
  );
}
