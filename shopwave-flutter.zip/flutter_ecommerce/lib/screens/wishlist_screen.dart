import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/wishlist_provider.dart';
import '../providers/auth_provider.dart';

class WishlistScreen extends StatelessWidget {
  const WishlistScreen({super.key});
  @override
  Widget build(BuildContext context) {
    final auth = context.watch<AuthProvider>();
    final wish = context.watch<WishlistProvider>();
    if (!auth.isLoggedIn) return Scaffold(appBar: AppBar(title: const Text('Wishlist')), body: Center(child: Column(mainAxisSize: MainAxisSize.min, children: [const Text('💝', style: TextStyle(fontSize: 56)), const SizedBox(height: 16), const Text('Sign in to view your wishlist'), const SizedBox(height: 24), ElevatedButton(onPressed: () => Navigator.pushNamed(context, '/login'), child: const Text('Sign In'))])));
    return Scaffold(
      appBar: AppBar(title: Text('Wishlist (${wish.ids.length})')),
      body: wish.ids.isEmpty ? const Center(child: Column(mainAxisSize: MainAxisSize.min, children: [Text('💝', style: TextStyle(fontSize: 72)), SizedBox(height: 16), Text('Your wishlist is empty', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w700)), SizedBox(height: 8), Text('Tap ♡ on any product to save it', style: TextStyle(color: Colors.grey))])) : const Center(child: Text('Wishlist items loaded from profile')),
    );
  }
}
