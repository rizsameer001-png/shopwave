import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../models/product.dart';
import '../providers/product_provider.dart';
import '../providers/cart_provider.dart';
import '../providers/wishlist_provider.dart';
import '../widgets/product_card.dart';
import '../main.dart';

class ProductDetailScreen extends StatefulWidget {
  final String productId;
  const ProductDetailScreen({super.key, required this.productId});
  @override
  State<ProductDetailScreen> createState() => _ProductDetailScreenState();
}

class _ProductDetailScreenState extends State<ProductDetailScreen> with SingleTickerProviderStateMixin {
  int _imgIdx = 0;
  String? _selectedSize;
  String? _selectedColor;
  int _qty = 1;
  late TabController _tabCtrl;

  @override
  void initState() {
    super.initState();
    _tabCtrl = TabController(length: 3, vsync: this);
    WidgetsBinding.instance.addPostFrameCallback((_) {
      context.read<ProductProvider>().fetchProduct(widget.productId);
      context.read<ProductProvider>().fetchRelated(widget.productId);
    });
  }

  @override
  void dispose() { _tabCtrl.dispose(); super.dispose(); }

  void _addToCart(Product p) {
    if (p.sizes.isNotEmpty && _selectedSize == null) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Please select a size'), backgroundColor: Colors.orange));
      return;
    }
    if (p.colors.isNotEmpty && _selectedColor == null) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Please select a color'), backgroundColor: Colors.orange));
      return;
    }
    context.read<CartProvider>().addItem(p, size: _selectedSize, color: _selectedColor, qty: _qty);
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Text('Added to cart! 🛍️'),
      backgroundColor: AppTheme.primaryColor,
      behavior: SnackBarBehavior.floating,
      action: SnackBarAction(label: 'View Cart', textColor: Colors.white, onPressed: () => Navigator.pushNamed(context, '/cart')),
    ));
  }

  @override
  Widget build(BuildContext context) {
    final pp    = context.watch<ProductProvider>();
    final wish  = context.watch<WishlistProvider>();
    final p     = pp.selected;

    if (pp.loading || p == null) return Scaffold(appBar: AppBar(), body: const Center(child: CircularProgressIndicator()));

    final isWishlisted = wish.isWishlisted(p.id);
    final images = p.images.isNotEmpty ? p.images : [ProductImage(url: 'https://via.placeholder.com/500')];

    return Scaffold(
      body: CustomScrollView(slivers: [
        SliverAppBar(
          expandedHeight: 340, pinned: true,
          actions: [
            IconButton(icon: Icon(isWishlisted ? Icons.favorite : Icons.favorite_border, color: isWishlisted ? AppTheme.secondaryColor : Colors.grey), onPressed: () => wish.toggle(p.id)),
            IconButton(icon: const Icon(Icons.shopping_cart_outlined), onPressed: () => Navigator.pushNamed(context, '/cart')),
          ],
          flexibleSpace: FlexibleSpaceBar(
            background: Stack(children: [
              PageView.builder(
                itemCount: images.length,
                onPageChanged: (i) => setState(() => _imgIdx = i),
                itemBuilder: (_, i) => Image.network(images[i].url, fit: BoxFit.cover, errorBuilder: (_, __, ___) => Container(color: Colors.grey.shade100, child: const Icon(Icons.image, size: 80, color: Colors.grey))),
              ),
              if (images.length > 1) Positioned(bottom: 12, left: 0, right: 0, child: Row(mainAxisAlignment: MainAxisAlignment.center, children: List.generate(images.length, (i) => AnimatedContainer(duration: const Duration(milliseconds: 200), margin: const EdgeInsets.symmetric(horizontal: 3), width: i == _imgIdx ? 20 : 6, height: 6, decoration: BoxDecoration(color: i == _imgIdx ? AppTheme.primaryColor : Colors.grey.shade300, borderRadius: BorderRadius.circular(3)))))),
              if (p.hasDiscount) Positioned(top: 60, left: 16, child: Container(padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4), decoration: BoxDecoration(color: AppTheme.secondaryColor, borderRadius: BorderRadius.circular(10)), child: Text('-${p.discountPercent}%', style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w700, fontSize: 13)))),
            ]),
          ),
        ),

        SliverToBoxAdapter(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Padding(padding: const EdgeInsets.fromLTRB(20, 20, 20, 0), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Row(children: [
              Container(padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4), decoration: BoxDecoration(color: AppTheme.primaryColor.withOpacity(0.1), borderRadius: BorderRadius.circular(8)), child: Text(p.category, style: const TextStyle(color: AppTheme.primaryColor, fontSize: 12, fontWeight: FontWeight.w600))),
              if (p.isNew) ...[const SizedBox(width: 8), Container(padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4), decoration: BoxDecoration(color: AppTheme.accentColor.withOpacity(0.15), borderRadius: BorderRadius.circular(8)), child: const Text('NEW', style: TextStyle(color: AppTheme.accentColor, fontSize: 12, fontWeight: FontWeight.w600)))],
              const Spacer(),
              if (!p.inStock) Container(padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4), decoration: BoxDecoration(color: Colors.red.shade50, borderRadius: BorderRadius.circular(8)), child: const Text('Out of Stock', style: TextStyle(color: Colors.red, fontSize: 12, fontWeight: FontWeight.w600))),
            ]),
            const SizedBox(height: 10),
            Text(p.name, style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w800, height: 1.2)),
            const SizedBox(height: 6),
            Text('by ${p.brand}', style: const TextStyle(color: Colors.grey, fontSize: 13)),
            const SizedBox(height: 10),
            Row(children: [
              const Icon(Icons.star, color: Color(0xFFF5A623), size: 18),
              const SizedBox(width: 4),
              Text('${p.rating.toStringAsFixed(1)} (${p.numReviews} reviews)', style: const TextStyle(fontSize: 13, color: Colors.grey)),
            ]),
            const SizedBox(height: 14),
            Row(crossAxisAlignment: CrossAxisAlignment.end, children: [
              Text('\$${p.effectivePrice.toStringAsFixed(2)}', style: const TextStyle(fontSize: 30, fontWeight: FontWeight.w800, color: AppTheme.primaryColor)),
              if (p.hasDiscount) ...[const SizedBox(width: 10), Padding(padding: const EdgeInsets.only(bottom: 4), child: Text('\$${p.price.toStringAsFixed(2)}', style: const TextStyle(fontSize: 16, color: Colors.grey, decoration: TextDecoration.lineThrough)))],
            ]),

            // Colors
            if (p.colors.isNotEmpty) ...[
              const SizedBox(height: 18),
              Text('Color: ${_selectedColor ?? 'Select'}', style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 14)),
              const SizedBox(height: 8),
              Wrap(spacing: 8, children: p.colors.map((c) {
                final selected = _selectedColor == c.name;
                final hex = c.hex.startsWith('#') ? c.hex.substring(1) : c.hex;
                final col = Color(int.parse('FF$hex', radix: 16));
                return GestureDetector(
                  onTap: () => setState(() => _selectedColor = c.name),
                  child: AnimatedContainer(duration: const Duration(milliseconds: 150),
                    width: 34, height: 34,
                    decoration: BoxDecoration(color: col, shape: BoxShape.circle, border: Border.all(color: selected ? AppTheme.primaryColor : Colors.transparent, width: 3), boxShadow: [if (selected) BoxShadow(color: AppTheme.primaryColor.withOpacity(0.4), blurRadius: 6)]),
                    child: selected ? const Icon(Icons.check, color: Colors.white, size: 16) : null,
                  ),
                );
              }).toList()),
            ],

            // Sizes
            if (p.sizes.isNotEmpty) ...[
              const SizedBox(height: 18),
              Text('Size: ${_selectedSize ?? 'Select'}', style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 14)),
              const SizedBox(height: 8),
              Wrap(spacing: 8, runSpacing: 8, children: p.sizes.map((s) {
                final selected = _selectedSize == s;
                return GestureDetector(
                  onTap: () => setState(() => _selectedSize = s),
                  child: AnimatedContainer(duration: const Duration(milliseconds: 150),
                    padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                    decoration: BoxDecoration(color: selected ? AppTheme.primaryColor : Colors.white, border: Border.all(color: selected ? AppTheme.primaryColor : Colors.grey.shade300), borderRadius: BorderRadius.circular(10)),
                    child: Text(s, style: TextStyle(fontWeight: FontWeight.w600, color: selected ? Colors.white : Colors.grey.shade700, fontSize: 13)),
                  ),
                );
              }).toList()),
            ],

            // Quantity
            const SizedBox(height: 18),
            Row(children: [
              const Text('Quantity', style: TextStyle(fontWeight: FontWeight.w700, fontSize: 14)),
              const SizedBox(width: 20),
              Container(decoration: BoxDecoration(border: Border.all(color: Colors.grey.shade300), borderRadius: BorderRadius.circular(12)), child: Row(children: [
                IconButton(icon: const Icon(Icons.remove, size: 18), onPressed: () => setState(() => _qty = (_qty - 1).clamp(1, p.stock))),
                SizedBox(width: 36, child: Text('$_qty', textAlign: TextAlign.center, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 16))),
                IconButton(icon: const Icon(Icons.add, size: 18), onPressed: () => setState(() => _qty = (_qty + 1).clamp(1, p.stock))),
              ])),
              const SizedBox(width: 12),
              Text('${p.stock} in stock', style: const TextStyle(color: Colors.grey, fontSize: 12)),
            ]),
          ])),

          // Tabs
          const SizedBox(height: 24),
          TabBar(
            controller: _tabCtrl,
            labelColor: AppTheme.primaryColor,
            unselectedLabelColor: Colors.grey,
            indicatorColor: AppTheme.primaryColor,
            tabs: [const Tab(text: 'Description'), const Tab(text: 'Specifications'), Tab(text: 'Reviews (${p.numReviews})')],
          ),
          SizedBox(height: 200, child: TabBarView(controller: _tabCtrl, children: [
            Padding(padding: const EdgeInsets.all(20), child: Text(p.description, style: const TextStyle(height: 1.7, color: Colors.black87))),
            Padding(padding: const EdgeInsets.all(16), child: p.tags.isEmpty ? const Center(child: Text('No specifications available')) : Column(children: p.tags.map((t) => Padding(padding: const EdgeInsets.symmetric(vertical: 4), child: Row(children: [const Icon(Icons.check_circle, size: 16, color: AppTheme.accentColor), const SizedBox(width: 8), Text(t)]))).toList())),
            const Padding(padding: EdgeInsets.all(20), child: Center(child: Text('Sign in to see and write reviews'))),
          ])),

          // Related
          if (pp.related.isNotEmpty) ...[
            const Padding(padding: EdgeInsets.fromLTRB(20, 24, 20, 12), child: Text('You May Also Like', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800))),
            SizedBox(height: 280, child: ListView.separated(
              scrollDirection: Axis.horizontal,
              padding: const EdgeInsets.symmetric(horizontal: 16),
              itemCount: pp.related.length,
              separatorBuilder: (_, __) => const SizedBox(width: 14),
              itemBuilder: (_, i) => SizedBox(width: 190, child: ProductCard(product: pp.related[i])),
            )),
          ],
          const SizedBox(height: 100),
        ])),
      ]),

      bottomNavigationBar: p.inStock ? SafeArea(child: Padding(
        padding: const EdgeInsets.fromLTRB(16, 8, 16, 16),
        child: Row(children: [
          Expanded(child: OutlinedButton(onPressed: () { _addToCart(p); }, style: OutlinedButton.styleFrom(padding: const EdgeInsets.symmetric(vertical: 16)), child: const Text('Add to Cart', style: TextStyle(fontWeight: FontWeight.w700)))),
          const SizedBox(width: 12),
          Expanded(child: ElevatedButton(onPressed: () { _addToCart(p); Navigator.pushNamed(context, '/checkout'); }, style: ElevatedButton.styleFrom(padding: const EdgeInsets.symmetric(vertical: 16)), child: const Text('Buy Now', style: TextStyle(fontWeight: FontWeight.w700)))),
        ]),
      )) : null,
    );
  }
}
