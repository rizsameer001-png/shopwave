import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/product_provider.dart';
import '../widgets/product_card.dart';
import '../main.dart';

const _SORTS = [
  {'label': 'Newest',       'value': 'newest'},
  {'label': 'Price ↑',      'value': 'price_asc'},
  {'label': 'Price ↓',      'value': 'price_desc'},
  {'label': 'Top Rated',    'value': 'rating'},
  {'label': 'Most Popular', 'value': 'popular'},
];

class SearchScreen extends StatefulWidget {
  const SearchScreen({super.key});
  @override
  State<SearchScreen> createState() => _SearchScreenState();
}

class _SearchScreenState extends State<SearchScreen> {
  final _ctrl = TextEditingController();
  String _sort = 'newest';
  String? _category;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) => context.read<ProductProvider>().fetchProducts(refresh: true));
  }

  void _search() => context.read<ProductProvider>().fetchProducts(refresh: true, keyword: _ctrl.text, category: _category, sort: _sort);

  @override
  Widget build(BuildContext context) {
    final pp = context.watch<ProductProvider>();
    return Scaffold(
      appBar: AppBar(
        title: TextField(
          controller: _ctrl,
          autofocus: true,
          decoration: const InputDecoration(hintText: 'Search products...', border: InputBorder.none, filled: false),
          onSubmitted: (_) => _search(),
          textInputAction: TextInputAction.search,
        ),
        actions: [IconButton(icon: const Icon(Icons.search), onPressed: _search)],
      ),
      body: Column(children: [
        // Filters
        SingleChildScrollView(scrollDirection: Axis.horizontal, padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10), child: Row(children: [
          ..._SORTS.map((s) {
            final sel = _sort == s['value'];
            return GestureDetector(onTap: () { setState(() => _sort = s['value']!); _search(); },
              child: Container(margin: const EdgeInsets.only(right: 8), padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 7), decoration: BoxDecoration(color: sel ? AppTheme.primaryColor : Colors.white, borderRadius: BorderRadius.circular(20), border: Border.all(color: sel ? AppTheme.primaryColor : Colors.grey.shade300)), child: Text(s['label']!, style: TextStyle(fontSize: 12, fontWeight: FontWeight.w600, color: sel ? Colors.white : Colors.grey.shade700))),
            );
          }),
        ])),
        Expanded(child: pp.loading && pp.products.isEmpty
          ? const Center(child: CircularProgressIndicator())
          : pp.products.isEmpty
              ? const Center(child: Column(mainAxisSize: MainAxisSize.min, children: [Text('🔍', style: TextStyle(fontSize: 56)), SizedBox(height: 12), Text('No products found', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w700))]))
              : GridView.builder(
                  padding: const EdgeInsets.all(16),
                  gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 2, childAspectRatio: 0.65, crossAxisSpacing: 14, mainAxisSpacing: 14),
                  itemCount: pp.products.length,
                  itemBuilder: (_, i) => ProductCard(product: pp.products[i]),
                )),
      ]),
    );
  }
}
