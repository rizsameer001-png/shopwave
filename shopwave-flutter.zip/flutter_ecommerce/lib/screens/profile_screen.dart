import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/auth_provider.dart';
import '../main.dart';

class ProfileScreen extends StatelessWidget {
  const ProfileScreen({super.key});
  @override
  Widget build(BuildContext context) {
    final auth = context.watch<AuthProvider>();
    if (!auth.isLoggedIn) return Scaffold(appBar: AppBar(title: const Text('Profile')), body: Center(child: Column(mainAxisSize: MainAxisSize.min, children: [const Text('👤', style: TextStyle(fontSize: 56)), const SizedBox(height: 16), ElevatedButton(onPressed: () => Navigator.pushNamed(context, '/login'), child: const Text('Sign In'))])));
    final user = auth.user!;
    return Scaffold(
      appBar: AppBar(title: const Text('My Profile')),
      body: ListView(padding: const EdgeInsets.all(20), children: [
        Center(child: Column(children: [
          CircleAvatar(radius: 48, backgroundImage: NetworkImage(user.avatarUrl)),
          const SizedBox(height: 12),
          Text(user.name, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w800)),
          Text(user.email, style: const TextStyle(color: Colors.grey)),
          if (user.isAdmin) Container(margin: const EdgeInsets.only(top: 6), padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 4), decoration: BoxDecoration(color: AppTheme.primaryColor.withOpacity(0.1), borderRadius: BorderRadius.circular(20)), child: const Text('Admin', style: TextStyle(color: AppTheme.primaryColor, fontWeight: FontWeight.w700))),
        ])),
        const SizedBox(height: 32),
        ListTile(leading: const Icon(Icons.shopping_bag_outlined, color: AppTheme.primaryColor), title: const Text('My Orders', style: TextStyle(fontWeight: FontWeight.w600)), trailing: const Icon(Icons.chevron_right), onTap: () => Navigator.pushNamed(context, '/orders')),
        ListTile(leading: const Icon(Icons.favorite_outline, color: AppTheme.primaryColor), title: const Text('Wishlist', style: TextStyle(fontWeight: FontWeight.w600)), trailing: const Icon(Icons.chevron_right), onTap: () => Navigator.pushNamed(context, '/wishlist')),
        const Divider(),
        ListTile(leading: const Icon(Icons.logout, color: Colors.red), title: const Text('Sign Out', style: TextStyle(color: Colors.red, fontWeight: FontWeight.w600)), onTap: () { auth.logout(); Navigator.pushReplacementNamed(context, '/home'); }),
      ]),
    );
  }
}
