import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../models/user.dart';
import '../providers/auth_provider.dart';
import '../services/api_service.dart';
import '../main.dart';

const _statusColors = {
  'Pending':    Color(0xFFF59E0B),
  'Processing': Color(0xFF3B82F6),
  'Confirmed':  Color(0xFF8B5CF6),
  'Shipped':    Color(0xFF06B6D4),
  'Delivered':  Color(0xFF22C55E),
  'Cancelled':  Color(0xFFEF4444),
  'Refunded':   Color(0xFF6B7280),
};

class OrdersScreen extends StatefulWidget {
  const OrdersScreen({super.key});
  @override
  State<OrdersScreen> createState() => _OrdersScreenState();
}

class _OrdersScreenState extends State<OrdersScreen> {
  List<Order> _orders = [];
  bool _loading = true;
  String? _error;

  @override
  void initState() { super.initState(); _loadOrders(); }

  Future<void> _loadOrders() async {
    setState(() { _loading = true; _error = null; });
    try {
      final data = await ApiService.getMyOrders();
      final list = data['orders'] as List? ?? data['data'] as List? ?? [];
      setState(() { _orders = list.map((j) => Order.fromJson(j as Map<String, dynamic>)).toList(); });
    } catch (e) {
      setState(() => _error = e.toString());
    } finally {
      setState(() => _loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final auth = context.watch<AuthProvider>();

    if (!auth.isLoggedIn) return Scaffold(
      appBar: AppBar(title: const Text('My Orders')),
      body: Center(child: Column(mainAxisSize: MainAxisSize.min, children: [
        const Text('🔒', style: TextStyle(fontSize: 56)),
        const SizedBox(height: 16),
        const Text('Please sign in to view orders', style: TextStyle(fontSize: 16)),
        const SizedBox(height: 24),
        ElevatedButton(onPressed: () => Navigator.pushNamed(context, '/login'), child: const Text('Sign In')),
      ])),
    );

    return Scaffold(
      appBar: AppBar(title: const Text('My Orders'), actions: [IconButton(icon: const Icon(Icons.refresh), onPressed: _loadOrders)]),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : _error != null
              ? Center(child: Column(mainAxisSize: MainAxisSize.min, children: [const Text('⚠️', style: TextStyle(fontSize: 48)), const SizedBox(height: 12), Text(_error!, textAlign: TextAlign.center, style: const TextStyle(color: Colors.grey)), const SizedBox(height: 16), ElevatedButton(onPressed: _loadOrders, child: const Text('Retry'))]))
              : _orders.isEmpty
                  ? Center(child: Column(mainAxisSize: MainAxisSize.min, children: [
                      const Text('📦', style: TextStyle(fontSize: 72)),
                      const SizedBox(height: 16),
                      const Text('No orders yet', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w700)),
                      const SizedBox(height: 8),
                      const Text('Your order history will appear here', style: TextStyle(color: Colors.grey)),
                      const SizedBox(height: 28),
                      ElevatedButton(onPressed: () => Navigator.pushNamed(context, '/search'), child: const Text('Start Shopping')),
                    ]))
                  : RefreshIndicator(
                      onRefresh: _loadOrders,
                      child: ListView.builder(
                        padding: const EdgeInsets.all(16),
                        itemCount: _orders.length,
                        itemBuilder: (ctx, i) => _OrderTile(order: _orders[i]),
                      ),
                    ),
    );
  }
}

class _OrderTile extends StatelessWidget {
  final Order order;
  const _OrderTile({required this.order});

  @override
  Widget build(BuildContext context) {
    final statusColor = _statusColors[order.status] ?? Colors.grey;
    return GestureDetector(
      onTap: () => showModalBottomSheet(
        context: context, isScrollControlled: true,
        shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(24))),
        builder: (_) => _OrderDetailSheet(order: order),
      ),
      child: Container(
        margin: const EdgeInsets.only(bottom: 12),
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(16), boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.05), blurRadius: 8)]),
        child: Column(children: [
          Row(children: [
            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text('Order #${order.orderNumber}', style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 15)),
              Text('${order.items.length} item(s) · ${_formatDate(order.createdAt)}', style: const TextStyle(color: Colors.grey, fontSize: 12)),
            ])),
            Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
              Text('\$${order.totalPrice.toStringAsFixed(2)}', style: const TextStyle(fontWeight: FontWeight.w800, color: AppTheme.primaryColor, fontSize: 16)),
              const SizedBox(height: 4),
              Container(padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 3), decoration: BoxDecoration(color: statusColor.withOpacity(0.12), borderRadius: BorderRadius.circular(20)), child: Text(order.status, style: TextStyle(color: statusColor, fontSize: 11, fontWeight: FontWeight.w700))),
            ]),
          ]),
          if (order.items.isNotEmpty) ...[
            const SizedBox(height: 10),
            SizedBox(height: 42, child: ListView.separated(
              scrollDirection: Axis.horizontal,
              itemCount: order.items.length.clamp(0, 4),
              separatorBuilder: (_, __) => const SizedBox(width: 6),
              itemBuilder: (_, i) => ClipRRect(borderRadius: BorderRadius.circular(8), child: Image.network(order.items[i].image, width: 42, height: 42, fit: BoxFit.cover, errorBuilder: (_, __, ___) => Container(width: 42, height: 42, color: Colors.grey.shade100))),
            )),
          ],
        ]),
      ),
    );
  }

  String _formatDate(DateTime d) => '${d.day}/${d.month}/${d.year}';
}

class _OrderDetailSheet extends StatelessWidget {
  final Order order;
  const _OrderDetailSheet({required this.order});

  @override
  Widget build(BuildContext context) {
    final statusColor = _statusColors[order.status] ?? Colors.grey;
    return DraggableScrollableSheet(
      initialChildSize: 0.75, maxChildSize: 0.95, minChildSize: 0.5, expand: false,
      builder: (_, ctrl) => ListView(controller: ctrl, padding: const EdgeInsets.all(20), children: [
        Center(child: Container(width: 36, height: 4, margin: const EdgeInsets.only(bottom: 20), decoration: BoxDecoration(color: Colors.grey.shade300, borderRadius: BorderRadius.circular(2)))),
        Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
          Text('Order #${order.orderNumber}', style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
          Container(padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 5), decoration: BoxDecoration(color: statusColor.withOpacity(0.12), borderRadius: BorderRadius.circular(20)), child: Text(order.status, style: TextStyle(color: statusColor, fontWeight: FontWeight.w700))),
        ]),
        const SizedBox(height: 20),
        ...order.items.map((item) => Padding(padding: const EdgeInsets.only(bottom: 12), child: Row(children: [
          ClipRRect(borderRadius: BorderRadius.circular(10), child: Image.network(item.image, width: 56, height: 56, fit: BoxFit.cover, errorBuilder: (_, __, ___) => Container(width: 56, height: 56, color: Colors.grey.shade100))),
          const SizedBox(width: 12),
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(item.name, maxLines: 2, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w600)), Text('\$${item.price.toStringAsFixed(2)} × ${item.quantity}', style: const TextStyle(color: Colors.grey, fontSize: 12))])),
          Text('\$${item.subtotal.toStringAsFixed(2)}', style: const TextStyle(fontWeight: FontWeight.w800)),
        ]))),
        const Divider(),
        _row('Subtotal', '\$${order.itemsPrice.toStringAsFixed(2)}'),
        _row('Shipping', order.shippingPrice == 0 ? 'FREE' : '\$${order.shippingPrice.toStringAsFixed(2)}'),
        _row('Tax', '\$${order.taxPrice.toStringAsFixed(2)}'),
        const Divider(),
        _row('Total', '\$${order.totalPrice.toStringAsFixed(2)}', bold: true),
        const SizedBox(height: 16),
        Container(padding: const EdgeInsets.all(14), decoration: BoxDecoration(color: Colors.grey.shade50, borderRadius: BorderRadius.circular(14)), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Text('📍 Shipping Address', style: TextStyle(fontWeight: FontWeight.w700, color: Colors.grey)),
          const SizedBox(height: 6),
          Text('${order.shippingAddress.fullName}\n${order.shippingAddress.formatted}', style: const TextStyle(fontSize: 14)),
        ])),
        const SizedBox(height: 12),
        Container(padding: const EdgeInsets.all(14), decoration: BoxDecoration(color: Colors.grey.shade50, borderRadius: BorderRadius.circular(14)), child: Row(children: [const Text('💳 Payment: ', style: TextStyle(fontWeight: FontWeight.w700, color: Colors.grey)), Text(order.paymentMethod)])),
        const SizedBox(height: 24),
      ]),
    );
  }

  Widget _row(String label, String value, {bool bold = false}) => Padding(
    padding: const EdgeInsets.symmetric(vertical: 4),
    child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
      Text(label, style: TextStyle(color: bold ? Colors.black87 : Colors.grey, fontWeight: bold ? FontWeight.w800 : FontWeight.w400)),
      Text(value, style: TextStyle(color: bold ? AppTheme.primaryColor : Colors.black87, fontWeight: bold ? FontWeight.w800 : FontWeight.w600, fontSize: bold ? 16 : 14)),
    ]),
  );
}
