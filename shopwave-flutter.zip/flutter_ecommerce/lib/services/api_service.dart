import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

// ─────────────────────────────────────────────────────────────────────────────
// CONFIGURE THIS — point to your deployed server or use localhost for local dev
// ─────────────────────────────────────────────────────────────────────────────
const String kBaseUrl = 'http://10.0.2.2:5000/api'; // Android emulator → localhost
// const String kBaseUrl = 'http://localhost:5000/api'; // iOS simulator
// const String kBaseUrl = 'https://your-deployed-backend.com/api'; // Production

class ApiService {
  static String? _token;

  // ── Token ────────────────────────────────────────────────────────────────
  static Future<void> loadToken() async {
    final prefs = await SharedPreferences.getInstance();
    _token = prefs.getString('shopwave_token');
  }

  static Future<void> saveToken(String token) async {
    _token = token;
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('shopwave_token', token);
  }

  static Future<void> clearToken() async {
    _token = null;
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove('shopwave_token');
    await prefs.remove('shopwave_user');
  }

  // ── Headers ───────────────────────────────────────────────────────────────
  static Map<String, String> get _headers => {
        'Content-Type': 'application/json',
        if (_token != null) 'Authorization': 'Bearer $_token',
      };

  // ── Core HTTP helpers ─────────────────────────────────────────────────────
  static Future<Map<String, dynamic>> _get(String path) async {
    final res = await http
        .get(Uri.parse('$kBaseUrl$path'), headers: _headers)
        .timeout(const Duration(seconds: 15));
    return _parse(res);
  }

  static Future<Map<String, dynamic>> _post(String path, Map<String, dynamic> body) async {
    final res = await http
        .post(Uri.parse('$kBaseUrl$path'), headers: _headers, body: jsonEncode(body))
        .timeout(const Duration(seconds: 15));
    return _parse(res);
  }

  static Future<Map<String, dynamic>> _put(String path, Map<String, dynamic> body) async {
    final res = await http
        .put(Uri.parse('$kBaseUrl$path'), headers: _headers, body: jsonEncode(body))
        .timeout(const Duration(seconds: 15));
    return _parse(res);
  }

  static Map<String, dynamic> _parse(http.Response res) {
    final data = jsonDecode(res.body);
    if (res.statusCode >= 200 && res.statusCode < 300) {
      if (data is List) return {'data': data, 'status': res.statusCode};
      return {...(data as Map<String, dynamic>), 'status': res.statusCode};
    }
    throw ApiException(
      message: (data as Map<String, dynamic>)['message'] ?? 'Request failed',
      statusCode: res.statusCode,
    );
  }

  // ══════════════════════════════════════════════════════════════════════════
  // AUTH
  // ══════════════════════════════════════════════════════════════════════════

  static Future<Map<String, dynamic>> login(String email, String password) async {
    final data = await _post('/auth/login', {'email': email, 'password': password});
    if (data['token'] != null) await saveToken(data['token']);
    return data;
  }

  static Future<Map<String, dynamic>> register(String name, String email, String password) async {
    final data = await _post('/auth/register', {'name': name, 'email': email, 'password': password});
    if (data['token'] != null) await saveToken(data['token']);
    return data;
  }

  static Future<Map<String, dynamic>> getMe() => _get('/auth/me');

  static Future<Map<String, dynamic>> updateProfile(Map<String, dynamic> body) =>
      _put('/auth/profile', body);

  static Future<Map<String, dynamic>> toggleWishlist(String productId) =>
      _post('/auth/wishlist/$productId', {});

  // ══════════════════════════════════════════════════════════════════════════
  // PRODUCTS
  // ══════════════════════════════════════════════════════════════════════════

  static Future<Map<String, dynamic>> getProducts({
    String? keyword,
    String? category,
    String? sort,
    int page = 1,
    int limit = 12,
    double? minPrice,
    double? maxPrice,
    bool? featured,
    bool? isNew,
  }) async {
    final params = <String, String>{
      'page': '$page',
      'limit': '$limit',
      if (keyword != null && keyword.isNotEmpty) 'keyword': keyword,
      if (category != null && category != 'All') 'category': category,
      if (sort != null && sort.isNotEmpty) 'sort': sort,
      if (minPrice != null) 'minPrice': '$minPrice',
      if (maxPrice != null) 'maxPrice': '$maxPrice',
      if (featured == true) 'featured': 'true',
      if (isNew == true) 'isNew': 'true',
    };
    final uri = Uri.parse('$kBaseUrl/products').replace(queryParameters: params);
    final res = await http.get(uri, headers: _headers).timeout(const Duration(seconds: 15));
    return _parse(res);
  }

  static Future<Map<String, dynamic>> getFeatured() => _get('/products/featured');
  static Future<Map<String, dynamic>> getNewArrivals() => _get('/products/new-arrivals');
  static Future<Map<String, dynamic>> getProduct(String id) => _get('/products/$id');
  static Future<Map<String, dynamic>> getRelated(String id) => _get('/products/$id/related');

  static Future<Map<String, dynamic>> addReview(
          String id, int rating, String comment) =>
      _post('/products/$id/reviews', {'rating': rating, 'comment': comment});

  // ══════════════════════════════════════════════════════════════════════════
  // ORDERS
  // ══════════════════════════════════════════════════════════════════════════

  static Future<Map<String, dynamic>> createOrder(Map<String, dynamic> payload) =>
      _post('/orders', payload);

  static Future<Map<String, dynamic>> getMyOrders({int page = 1}) async {
    final uri = Uri.parse('$kBaseUrl/orders/my').replace(queryParameters: {'page': '$page', 'limit': '20'});
    final res = await http.get(uri, headers: _headers).timeout(const Duration(seconds: 15));
    return _parse(res);
  }

  static Future<Map<String, dynamic>> getOrder(String id) => _get('/orders/$id');

  // ══════════════════════════════════════════════════════════════════════════
  // CATEGORIES
  // ══════════════════════════════════════════════════════════════════════════

  static Future<Map<String, dynamic>> getCategories() => _get('/categories');
}

class ApiException implements Exception {
  final String message;
  final int statusCode;
  ApiException({required this.message, required this.statusCode});
  @override
  String toString() => 'ApiException($statusCode): $message';
}
